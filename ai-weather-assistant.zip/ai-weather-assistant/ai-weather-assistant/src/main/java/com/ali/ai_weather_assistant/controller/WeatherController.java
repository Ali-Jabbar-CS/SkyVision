package com.ali.ai_weather_assistant.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WeatherController {

    @GetMapping("/test")
    public String test(@RequestParam String city) {
        return "Controller works: " + city;
    }
}